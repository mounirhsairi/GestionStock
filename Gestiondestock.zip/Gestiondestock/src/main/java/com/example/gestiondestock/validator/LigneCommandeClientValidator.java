package com.example.gestiondestock.validator;

import java.util.List;

import com.example.gestiondestock.DTO.LigneCommandeClientDto;

public class LigneCommandeClientValidator {

	public static List<String> validate(LigneCommandeClientDto dto) {
		// TODO Auto-generated method stub
		return null;
	}

}
