package com.example.gestiondestock.Service;







public interface LigneCommandeClientService {
	
	
	/*LigneCommandeClientDto save(LigneCommandeClientDto dto);
	LigneCommandeClientDto findById(Integer id);
	List<LigneCommandeClientDto> findAll();
	void delete(Integer id);*/
}
