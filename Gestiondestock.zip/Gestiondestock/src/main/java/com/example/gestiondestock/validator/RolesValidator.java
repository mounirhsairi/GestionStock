package com.example.gestiondestock.validator;

public class RolesValidator {

}
