package com.example.gestiondestock.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;

import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.gestiondestock.DTO.auth.AuthenticationResponse;
import com.example.gestiondestock.DTO.auth.LoginDto;
import com.example.gestiondestock.DTO.auth.SignUpDto;
import com.example.gestiondestock.Service.AuthenticationService;

import lombok.RequiredArgsConstructor;


@RestController
public class AuthController {

	private  AuthenticationService authenticationService;

	private  UserDetailsService userDetailsService ;

	

	
	@Autowired
	public AuthController(AuthenticationService authenticationService, UserDetailsService userDetailsService) {
		
		this.authenticationService = authenticationService;
		this.userDetailsService = userDetailsService;
	}

	public ResponseEntity<AuthenticationResponse>authenticate(@RequestBody LoginDto request){
		 
		return ResponseEntity.ok(authenticationService.authenticate(request));
	}
	
	public ResponseEntity<AuthenticationResponse>RegisterUser(@RequestBody SignUpDto request){
		
		return ResponseEntity.ok(authenticationService.register(request));
	
	
	
	}
	
	
}
