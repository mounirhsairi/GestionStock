package com.example.gestiondestock.model;

public enum SourceMvtStock {

	COMMANDE_CLIENT,
	COMMANDE_FOURNISSEUR,
	VENTE
}
