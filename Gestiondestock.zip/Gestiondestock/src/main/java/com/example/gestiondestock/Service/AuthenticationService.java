package com.example.gestiondestock.Service;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.gestiondestock.DTO.auth.AuthenticationResponse;
import com.example.gestiondestock.DTO.auth.LoginDto;
import com.example.gestiondestock.DTO.auth.SignUpDto;
import com.example.gestiondestock.model.User;
import com.example.gestiondestock.repository.UserRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AuthenticationService {
	private  UserRepository repository ;
	private  PasswordEncoder passwordEncoder ;
	private  JwtUtils jwtUtils ;
    private  AuthenticationManager authenticationManager;

	
	public AuthenticationResponse authenticate(LoginDto request) {
		 Authentication authentication = authenticationManager.authenticate(
		            new UsernamePasswordAuthenticationToken(
		                request.getUsernameOrEmail(),
		                request.getMdp()
		            )
		        );
		 SecurityContextHolder.getContext().setAuthentication(authentication);
		
		var user = repository.findByEmail(request.getUsernameOrEmail())
				.orElseThrow();
		
		var jwtToken = jwtUtils.generateToken(user);
		return AuthenticationResponse.builder()
				.token(jwtToken)
				.build();
	}

public AuthenticationResponse register(SignUpDto request) {
	var user =User.builder()
			.name(request.getName())
			.email(request.getEmail())
			.password(passwordEncoder.encode(request.getMdp()))
			.username(request.getUsername())
			.build();
	repository.save(user);
	var jwtToken = jwtUtils.generateToken(user);
	return AuthenticationResponse.builder()
			.token(jwtToken)
			.build();
			
}



}
