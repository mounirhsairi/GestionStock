package com.example.gestiondestock.validator;

public class LigneVenteValidator {

}
