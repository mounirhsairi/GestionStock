package com.example.gestiondestock.controller.api;


import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.gestiondestock.DTO.auth.AuthenticationResponse;
import com.example.gestiondestock.DTO.auth.LoginDto;
import com.example.gestiondestock.DTO.auth.SignUpDto;

import io.swagger.annotations.Api;

@Api("/api/v1/auth")

public interface AuthApi {
	@PostMapping("/api/v1/auth/authenticate")
	public ResponseEntity<AuthenticationResponse>authenticate(@RequestBody LoginDto request);
	@PostMapping("/api/v1/auth/register")
	public ResponseEntity<AuthenticationResponse>RegisterUser(@RequestBody SignUpDto request);
}
