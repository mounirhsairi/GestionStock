package com.example.gestiondestock.model;

public enum EtatCommande {

	EN_PREPARATION,
	VALIDEE,
	LIVREE
}
