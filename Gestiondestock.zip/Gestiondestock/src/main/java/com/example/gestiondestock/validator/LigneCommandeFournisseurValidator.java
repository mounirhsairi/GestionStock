package com.example.gestiondestock.validator;

import java.util.List;

import com.example.gestiondestock.DTO.LigneCommandeFournisseurDto;

public class LigneCommandeFournisseurValidator {

	public static List<String> validate(LigneCommandeFournisseurDto dto) {
		// TODO Auto-generated method stub
		return null;
	}

}
