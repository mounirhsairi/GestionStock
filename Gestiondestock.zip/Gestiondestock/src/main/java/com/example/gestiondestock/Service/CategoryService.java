package com.example.gestiondestock.Service;

import java.util.List;

import com.example.gestiondestock.DTO.CategoryDto;

public interface CategoryService {
	CategoryDto save(CategoryDto dto);
	CategoryDto findById(Integer id);
	List<CategoryDto> findAllByCodeCategory(String code);
	CategoryDto updateCategory(Integer idCategory, CategoryDto categoryDto);
	List<CategoryDto> findAll();
	void delete(Integer id);
	
}
