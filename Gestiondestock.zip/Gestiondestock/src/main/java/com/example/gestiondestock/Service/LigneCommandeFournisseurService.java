package com.example.gestiondestock.Service;


public interface LigneCommandeFournisseurService {
	/*LigneCommandeFournisseurDto save(LigneCommandeFournisseurDto dto);
	LigneCommandeFournisseurDto findById(Integer id);
	List<LigneCommandeFournisseurDto> findAll();
	void delete(Integer id);*/
}
