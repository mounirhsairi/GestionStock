package com.example.gestiondestock.Service;


import java.sql.Date;

import java.util.Map;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;


import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;

@Service
public class JwtUtils {

	private final String jwtSigningKey = "secret";
	public String extractUsername(String token) {
		return extractClaim(token,Claims::getSubject);
	}
	public Date extractExpiration(String token) {
		return (Date) extractClaim(token,Claims::getExpiration);
	}
	public <T>T extractClaim(String token,Function<Claims,T>claimsResolver){
		final Claims claims =extractAllClaims(token);
		return claimsResolver.apply(claims);
	}
	public boolean hashClaim(String token ,String ClaimName) {
		final Claims claims = extractAllClaims(token);
		return claims.get(ClaimName)!=null ;
	}
	private Claims extractAllClaims(String token) {
		return  Jwts
				.parserBuilder()
				.setSigningKey(jwtSigningKey())
				.build()
				.parseClaimsJws(token)
				.getBody();
	}
	private java.security.Key jwtSigningKey() {

		byte[]keyBytes =Decoders.BASE64.decode(jwtSigningKey);
		return Keys.hmacShaKeyFor(keyBytes);
	}
	private Boolean isTokenExpired(String token) {
		return extractExpiration(token).before(new Date(0));
	}
	public String generateToken (UserDetails userDetails) {
		//Map<String,Object>claims = new HashMap<>();
		return generateToken(userDetails ,new HashMap<>());
	}
	public String generateToken(UserDetails userDetails ,Map<String,Object>claims) {
		return createToken(claims,userDetails);
	}
	private String createToken(Map<String,Object>claims,UserDetails userDetails) {
		return Jwts.builder().setClaims(claims).setSubject(userDetails.getUsername())
				.claim("authorities", userDetails.getAuthorities())
				.setIssuedAt(new Date(System.currentTimeMillis()))
				.setExpiration(new Date(System.currentTimeMillis()+TimeUnit.HOURS.toMillis(24)))
				.signWith(jwtSigningKey(),SignatureAlgorithm.HS256).compact();
	}
	public Boolean isTokenValid(String token ,UserDetails userDetails) {
		final String username =extractUsername(token);
		return(username.equals(userDetails.getUsername())&& !isTokenExpired(token));
		
	}
}
