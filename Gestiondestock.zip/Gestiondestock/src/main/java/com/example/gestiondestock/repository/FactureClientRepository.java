package com.example.gestiondestock.repository;



import org.springframework.data.jpa.repository.JpaRepository;

import com.example.gestiondestock.model.FactureClient;

public interface FactureClientRepository extends JpaRepository<FactureClient,Integer>{




}
