package com.example.gestiondestock.utils;

public interface Constants {
	
public static String APP_ROOT ="gestiondestock/v1";
}
