package com.example.gestiondestock.model;

public enum TypeMvtStock {

	ENTREE,SORTIE,CORRECTIN_POS,CORRECTION_NEG
}
