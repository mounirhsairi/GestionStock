package com.example.gestiondestock.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.gestiondestock.model.LigneFactureRetour;

public interface LigneFactureRetourRepository  extends JpaRepository<LigneFactureRetour,Integer>{

}
